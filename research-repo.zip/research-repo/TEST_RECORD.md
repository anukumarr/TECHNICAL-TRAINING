# Test Record – Research Data Repository

**How tested:** `node tests/run-tests.js` (29 automated checks) + manual browser checks.
**Result:** 29 / 29 automated tests passed.

## 1. Requirement coverage

| Requirement | Test IDs | What was checked | Result |
|---|---|---|---|
| Store project metadata | T1, T2 | Valid record is saved; keywords are de-duplicated; size is stored as a number | Pass |
| Search records | T3 – T7 | Search by title/keyword, case-insensitive, status filter, discipline filter, combined filters, blank search, no-match search | Pass |
| Generate summaries | T8 – T10 | Total count, total/average size, count by status, top discipline, date range, summary sentence, empty-repository case | Pass |
| Edit / update | T11, T12 | Update changes the record without adding a new one; own title is not flagged as duplicate; unknown id is handled | Pass |
| Delete | T13 | Record removed; deleting twice is handled | Pass |

## 2. Validation / edge cases

| ID | Input | Expected | Result |
|---|---|---|---|
| T14 | Empty title | Error | Pass |
| T15 | Title of only spaces | Error | Pass |
| T16 | Title under 3 characters | Error | Pass |
| T17 | Title over 80 characters | Error | Pass |
| T18 | Same title, different letter case | Duplicate error | Pass |
| T19 | Researcher "R2D2" (digits) | Error | Pass |
| T20 | No discipline chosen | Error | Pass |
| T21 | Status outside the allowed list | Error | Pass |
| T22 | Date 2026-02-30 | Error | Pass |
| T23 | Missing start date | Error | Pass |
| T24 | Negative size | Error | Pass |
| T25 | Size "abc" | Error | Pass |
| T26 | Empty size | Error | Pass |
| T27 | More than 10 keywords | Error | Pass |
| T28 | Description over 300 characters | Error | Pass |
| T29 | Size 0 | Accepted | Pass |

## 3. Sample summary produced by the program

With the three test records (before the delete in T13):

> The repository holds 3 projects with 470.5 MB of data in total (average 156.8 MB). 1 ongoing, 1 completed, 1 planned. Most projects are in Agriculture.

Raw output of the test run is saved in `tests/test-output.txt`.

## 4. Manual browser checks

| Check | Expected |
|---|---|
| Submit empty form | Red messages under every required field |
| Save a valid project | Appears in the listing; summary numbers update |
| Click Edit | Form fills with the record; heading and button change to "Update" |
| Click Update | Listing changes; no duplicate created |
| Type in search box | Listing filters as you type; "Showing X of Y" updates |
| Resize window below 760px | Layout becomes one column; form fields stack |
| Refresh the page | Records are still there (localStorage) |
