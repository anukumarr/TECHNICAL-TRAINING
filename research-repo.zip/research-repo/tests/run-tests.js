/* Run with:  node tests/run-tests.js
   Checks the three core requirements plus edit / search / edge cases. */
var V = require('../js/validate.js');
var S = require('../js/store.js');
var M = require('../js/summary.js');

var results = [];
function test(id, requirement, fn) {
  var ok = false, note = '';
  try { fn(); ok = true; } catch (e) { note = e.message; }
  results.push({ id: id, requirement: requirement, ok: ok, note: note });
}
function eq(a, b, msg) {
  if (a !== b) throw new Error((msg || 'values differ') + ' (got ' + a + ', expected ' + b + ')');
}
function good(over) {
  return Object.assign({
    title: 'Soil moisture survey', researcher: 'Dr. A. Kaur', discipline: 'Agriculture',
    status: 'Ongoing', startDate: '2026-03-10', size: '120.5',
    keywords: 'soil, water, Soil', description: 'Field sensor readings.'
  }, over || {});
}

S.clearAll();

/* ---- Requirement A: store project metadata ---- */
test('T1', 'Store metadata', function () {
  var r = V.validateProject(good(), S.getAll(), null);
  eq(r.valid, true, 'valid record rejected');
  S.add(r.value);
  eq(S.getAll().length, 1, 'record not stored');
  eq(S.getAll()[0].title, 'Soil moisture survey');
});
test('T2', 'Store metadata', function () {
  var k = S.getAll()[0].keywords;
  eq(k.length, 2, 'duplicate keyword not removed');
  eq(typeof S.getAll()[0].size, 'number', 'size should be stored as a number');
});

// add more records for search / summary
S.add(V.validateProject(good({ title: 'Protein folding data', researcher: 'R. Singh', discipline: 'Biology',
  status: 'Completed', startDate: '2025-01-15', size: '300', keywords: 'protein, folding' }), [], null).value);
S.add(V.validateProject(good({ title: 'Crop yield study', researcher: 'M. Gill', discipline: 'Agriculture',
  status: 'Planned', startDate: '2026-09-01', size: '50', keywords: 'wheat, yield' }), [], null).value);

/* ---- Requirement B: search records ---- */
test('T3', 'Search records', function () {
  eq(S.search(S.getAll(), { text: 'protein' }).length, 1, 'title/keyword search failed');
});
test('T4', 'Search records', function () {
  eq(S.search(S.getAll(), { text: 'GILL' }).length, 1, 'search should ignore case');
});
test('T5', 'Search records', function () {
  eq(S.search(S.getAll(), { status: 'Ongoing' }).length, 1, 'status filter failed');
  eq(S.search(S.getAll(), { discipline: 'Agriculture' }).length, 2, 'discipline filter failed');
});
test('T6', 'Search records', function () {
  eq(S.search(S.getAll(), { text: 'wheat', discipline: 'Agriculture', status: 'Planned' }).length, 1, 'combined filter failed');
  eq(S.search(S.getAll(), { text: 'wheat', status: 'Completed' }).length, 0, 'combined filter should give no match');
});
test('T7', 'Search records (edge)', function () {
  eq(S.search(S.getAll(), { text: '   ' }).length, 3, 'blank search should return all');
  eq(S.search(S.getAll(), { text: 'zzzz' }).length, 0, 'unknown word should return none');
});

/* ---- Requirement C: generate summaries ---- */
test('T8', 'Generate summary', function () {
  var s = M.generate(S.getAll());
  eq(s.total, 3, 'total wrong');
  eq(s.totalSizeMB, 470.5, 'total size wrong');
  eq(s.avgSizeMB, 156.8, 'average size wrong');
  eq(s.byStatus.Completed, 1, 'status count wrong');
  eq(s.topDiscipline, 'Agriculture', 'top discipline wrong');
  eq(s.earliest, '2025-01-15', 'earliest date wrong');
});
test('T9', 'Generate summary', function () {
  var s = M.generate(S.getAll());
  if (s.text.indexOf('3 projects') === -1) throw new Error('summary sentence missing count');
});
test('T10', 'Generate summary (edge)', function () {
  var s = M.generate([]);
  eq(s.total, 0, 'empty total');
  eq(s.text, 'No projects stored yet.', 'empty summary text');
});

/* ---- Edit / update ---- */
test('T11', 'Edit / update', function () {
  var id = S.getAll()[0].id;
  var r = V.validateProject(good({ status: 'Completed', size: '200' }), S.getAll(), id);
  eq(r.valid, true, 'editing own title should not count as duplicate');
  var u = S.update(id, r.value);
  eq(u.status, 'Completed', 'status not updated');
  eq(S.getById(id).size, 200, 'size not updated');
  eq(S.getAll().length, 3, 'update must not add a new record');
});
test('T12', 'Edit / update (edge)', function () {
  eq(S.update('does-not-exist', { title: 'x' }), null, 'unknown id should return null');
});
test('T13', 'Delete', function () {
  var id = S.getAll()[2].id;
  eq(S.remove(id), true, 'remove failed');
  eq(S.remove(id), false, 'second remove should fail');
  eq(S.getAll().length, 2, 'count after delete');
});

/* ---- Validation edge cases ---- */
function bad(over, field, label) {
  var parts = label.split(' ');
  test(parts[0], 'Validation: ' + parts.slice(1).join(' '), function () {
    var r = V.validateProject(good(over), S.getAll(), null);
    eq(r.valid, false, 'should be invalid');
    if (!r.errors[field]) throw new Error('expected error on ' + field);
  });
}
bad({ title: '' }, 'title', 'T14 empty title');
bad({ title: '   ' }, 'title', 'T15 blank-spaces title');
bad({ title: 'ab' }, 'title', 'T16 title too short');
bad({ title: 'x'.repeat(81) }, 'title', 'T17 title too long');
bad({ title: 'protein FOLDING data' }, 'title', 'T18 duplicate title (case-insensitive)');
bad({ researcher: 'R2D2' }, 'researcher', 'T19 digits in researcher');
bad({ discipline: '' }, 'discipline', 'T20 no discipline');
bad({ status: 'Unknown' }, 'status', 'T21 invalid status');
bad({ startDate: '2026-02-30' }, 'startDate', 'T22 impossible date');
bad({ startDate: '' }, 'startDate', 'T23 missing date');
bad({ size: '-5' }, 'size', 'T24 negative size');
bad({ size: 'abc' }, 'size', 'T25 non-numeric size');
bad({ size: '' }, 'size', 'T26 empty size');
bad({ keywords: 'a,b,c,d,e,f,g,h,i,j,k' }, 'keywords', 'T27 too many keywords');
bad({ description: 'y'.repeat(301) }, 'description', 'T28 description too long');
test('T29', 'Validation', function () {
  var r = V.validateProject(good({ title: 'Tiny pilot dataset', size: '0' }), S.getAll(), null);
  eq(r.valid, true, 'size 0 should be allowed');
});

/* ---- print record ---- */
var pass = results.filter(function (r) { return r.ok; }).length;
console.log('ID    | Result | Requirement');
console.log('------|--------|-----------------------------');
results.forEach(function (r) {
  console.log(String(r.id).padEnd(5) + ' | ' + (r.ok ? 'PASS  ' : 'FAIL  ') + ' | ' + r.requirement + (r.note ? '  -> ' + r.note : ''));
});
console.log('\n' + pass + ' / ' + results.length + ' tests passed');
process.exit(pass === results.length ? 0 : 1);
