# Research Data Repository

A simple front-end project (HTML5, CSS3, JavaScript). It covers both practical questions in one program.

## Run
Open `index.html` in a browser. No server or install needed. Data is kept in the browser's localStorage.

## Files
| File | Purpose |
|---|---|
| `index.html` | Page structure: form, summary, search/filter bar, listing |
| `css/style.css` | Styling and responsive layout (media query at 760px) |
| `js/validate.js` | Input validation and cleaning |
| `js/store.js` | Save / update / delete / search records |
| `js/summary.js` | Summary figures and text |
| `js/app.js` | Connects the page to the modules |
| `tests/run-tests.js` | Automated tests (`node tests/run-tests.js`) |
| `TEST_RECORD.md` | Test record for the exam |

## Question 1 – covered by
Form with text, select, date, number and textarea inputs; validation messages; a resulting card listing; responsive CSS; storing metadata, searching and summary.

## Question 2 – covered by
Edit/Update (Edit button on each card), delete, search box with status and discipline filters, code split into four modules, edge-case validation, and the test record.
