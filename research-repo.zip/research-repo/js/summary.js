/* summary.js - builds summary figures and a readable sentence from records. */
(function (root) {
  'use strict';

  function countBy(list, field) {
    var out = {};
    list.forEach(function (r) {
      var k = r[field] || 'Unknown';
      out[k] = (out[k] || 0) + 1;
    });
    return out;
  }

  function topKey(counts) {
    var best = null;
    Object.keys(counts).forEach(function (k) {
      if (best === null || counts[k] > counts[best]) best = k;
    });
    return best;
  }

  function round1(n) { return Math.round(n * 10) / 10; }

  function generate(list) {
    var total = list.length;
    if (total === 0) {
      return {
        total: 0, byStatus: {}, byDiscipline: {}, totalSizeMB: 0,
        avgSizeMB: 0, topDiscipline: null, earliest: null, latest: null,
        text: 'No projects stored yet.'
      };
    }

    var sizes = list.map(function (r) { return Number(r.size) || 0; });
    var sum = sizes.reduce(function (a, b) { return a + b; }, 0);
    var dates = list.map(function (r) { return r.startDate; }).filter(Boolean).sort();

    var byStatus = countBy(list, 'status');
    var byDiscipline = countBy(list, 'discipline');
    var top = topKey(byDiscipline);

    var s = {
      total: total,
      byStatus: byStatus,
      byDiscipline: byDiscipline,
      totalSizeMB: round1(sum),
      avgSizeMB: round1(sum / total),
      topDiscipline: top,
      earliest: dates[0] || null,
      latest: dates[dates.length - 1] || null
    };

    s.text = 'The repository holds ' + total + (total === 1 ? ' project' : ' projects') +
      ' with ' + s.totalSizeMB + ' MB of data in total (average ' + s.avgSizeMB + ' MB). ' +
      (byStatus.Ongoing || 0) + ' ongoing, ' + (byStatus.Completed || 0) + ' completed, ' +
      (byStatus.Planned || 0) + ' planned. Most projects are in ' + top + '.';
    return s;
  }

  var api = { generate: generate, countBy: countBy };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.RepoSummary = api;
})(typeof window !== 'undefined' ? window : globalThis);
