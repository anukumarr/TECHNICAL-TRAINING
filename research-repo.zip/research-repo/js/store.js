/* store.js - storing, updating, deleting and searching project records.
   Uses localStorage in the browser; falls back to memory (used by tests). */
(function (root) {
  'use strict';

  var KEY = 'research_repo_projects_v1';
  var memory = null; // used when localStorage is not available

  function hasStorage() {
    try {
      var t = '__t';
      root.localStorage.setItem(t, '1');
      root.localStorage.removeItem(t);
      return true;
    } catch (e) { return false; }
  }

  function load() {
    if (!hasStorage()) return memory ? memory.slice() : [];
    try {
      var list = JSON.parse(root.localStorage.getItem(KEY) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) { return []; } // corrupted data -> start clean
  }

  function save(list) {
    if (!hasStorage()) { memory = list.slice(); return; }
    root.localStorage.setItem(KEY, JSON.stringify(list));
  }

  function newId() {
    return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function getAll() { return load(); }

  function getById(id) {
    return load().filter(function (r) { return r.id === id; })[0] || null;
  }

  function add(fields) {
    var list = load();
    var rec = Object.assign({}, fields, { id: newId(), createdAt: new Date().toISOString() });
    list.push(rec);
    save(list);
    return rec;
  }

  // returns updated record, or null if the id does not exist
  function update(id, fields) {
    var list = load();
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) {
        list[i] = Object.assign({}, list[i], fields, {
          id: id,
          createdAt: list[i].createdAt,
          updatedAt: new Date().toISOString()
        });
        save(list);
        return list[i];
      }
    }
    return null;
  }

  function remove(id) {
    var list = load();
    var next = list.filter(function (r) { return r.id !== id; });
    if (next.length === list.length) return false;
    save(next);
    return true;
  }

  function clearAll() { save([]); }

  /* search(list, {text, status, discipline})
     - text: every word typed must appear somewhere in title/researcher/
       discipline/keywords/description (case-insensitive)
     - status / discipline: exact match, empty = no filter */
  function search(list, q) {
    q = q || {};
    var words = String(q.text || '').toLowerCase().split(/\s+/).filter(Boolean);
    return list.filter(function (r) {
      if (q.status && r.status !== q.status) return false;
      if (q.discipline && r.discipline !== q.discipline) return false;
      var haystack = [r.title, r.researcher, r.discipline,
        (r.keywords || []).join(' '), r.description || ''].join(' ').toLowerCase();
      return words.every(function (w) { return haystack.indexOf(w) !== -1; });
    });
  }

  var api = {
    getAll: getAll, getById: getById, add: add, update: update,
    remove: remove, clearAll: clearAll, search: search
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.RepoStore = api;
})(typeof window !== 'undefined' ? window : globalThis);
