/* app.js - connects the page (DOM) with validate / store / summary modules. */
(function () {
  'use strict';

  var V = window.RepoValidate;
  var S = window.RepoStore;
  var M = window.RepoSummary;

  var FIELDS = ['title', 'researcher', 'discipline', 'status', 'startDate', 'size', 'keywords', 'description'];

  function $(id) { return document.getElementById(id); }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------- form helpers ---------- */
  function readForm() {
    var data = {};
    FIELDS.forEach(function (f) { data[f] = $(f).value; });
    return data;
  }

  function showErrors(errors) {
    FIELDS.forEach(function (f) {
      var box = $('err-' + f);
      if (box) box.textContent = errors[f] || '';
      $(f).classList.toggle('invalid', !!errors[f]);
    });
  }

  function setMessage(text, bad) {
    var m = $('form-msg');
    m.textContent = text;
    m.className = 'msg' + (bad ? ' bad' : '');
  }

  function resetForm() {
    $('project-form').reset();
    $('project-id').value = '';
    $('form-title').textContent = 'Add Project';
    $('save-btn').textContent = 'Save Project';
    $('cancel-btn').hidden = true;
    $('char-count').textContent = '0';
    showErrors({});
  }

  function fillForm(rec) {
    FIELDS.forEach(function (f) {
      $(f).value = f === 'keywords' ? (rec.keywords || []).join(', ') : (rec[f] == null ? '' : rec[f]);
    });
    $('project-id').value = rec.id;
    $('form-title').textContent = 'Edit Project';
    $('save-btn').textContent = 'Update Project';
    $('cancel-btn').hidden = false;
    $('char-count').textContent = String($('description').value.length);
    showErrors({});
    $('title').focus();
    $('project-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- rendering ---------- */
  function refreshDisciplineFilter() {
    var select = $('filter-discipline');
    var current = select.value;
    var names = Object.keys(M.countBy(S.getAll(), 'discipline')).sort();
    select.innerHTML = '<option value="">All disciplines</option>' +
      names.map(function (n) {
        return '<option' + (n === current ? ' selected' : '') + '>' + escapeHtml(n) + '</option>';
      }).join('');
  }

  function renderSummary() {
    var s = M.generate(S.getAll());
    var html = '<div class="stats">' +
      '<div class="stat"><b>' + s.total + '</b><span>Projects</span></div>' +
      '<div class="stat"><b>' + s.totalSizeMB + '</b><span>Total MB</span></div>' +
      '<div class="stat"><b>' + s.avgSizeMB + '</b><span>Avg MB</span></div></div>';

    if (s.total) {
      html += '<ul class="summary-list">';
      Object.keys(s.byStatus).forEach(function (k) {
        html += '<li>' + escapeHtml(k) + ': ' + s.byStatus[k] + '</li>';
      });
      html += '</ul>';
      html += '<p class="hint">Start dates: ' + escapeHtml(s.earliest) + ' to ' + escapeHtml(s.latest) + '</p>';
    }
    html += '<p class="summary-text">' + escapeHtml(s.text) + '</p>';
    $('summary-box').innerHTML = html;
  }

  function currentQuery() {
    return {
      text: $('search').value,
      status: $('filter-status').value,
      discipline: $('filter-discipline').value
    };
  }

  function renderListing() {
    var all = S.getAll();
    var found = S.search(all, currentQuery());

    $('result-count').textContent = 'Showing ' + found.length + ' of ' + all.length + ' record(s)';

    if (!found.length) {
      $('listing').innerHTML = '<p class="empty">' +
        (all.length ? 'No records match your search.' : 'No records yet. Add your first project.') + '</p>';
      return;
    }

    $('listing').innerHTML = found.map(function (r) {
      return '<article class="record">' +
        '<h3>' + escapeHtml(r.title) + '</h3>' +
        '<p><span class="badge ' + escapeHtml(r.status) + '">' + escapeHtml(r.status) + '</span> ' +
        escapeHtml(r.discipline) + '</p>' +
        '<p class="meta">Researcher: ' + escapeHtml(r.researcher) + '</p>' +
        '<p class="meta">Started: ' + escapeHtml(r.startDate) + ' &middot; ' + escapeHtml(r.size) + ' MB</p>' +
        (r.keywords && r.keywords.length ? '<p class="meta">Keywords: ' + escapeHtml(r.keywords.join(', ')) + '</p>' : '') +
        (r.description ? '<p>' + escapeHtml(r.description) + '</p>' : '') +
        '<div class="actions">' +
        '<button type="button" class="small" data-action="edit" data-id="' + escapeHtml(r.id) + '">Edit</button>' +
        '<button type="button" class="small danger" data-action="delete" data-id="' + escapeHtml(r.id) + '">Delete</button>' +
        '</div></article>';
    }).join('');
  }

  function refreshAll() {
    refreshDisciplineFilter();
    renderSummary();
    renderListing();
  }

  /* ---------- events ---------- */
  $('project-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var editId = $('project-id').value || null;
    var result = V.validateProject(readForm(), S.getAll(), editId);
    showErrors(result.errors);

    if (!result.valid) {
      setMessage('Please fix the highlighted fields.', true);
      return;
    }

    if (editId) {
      if (!S.update(editId, result.value)) {
        setMessage('That record no longer exists.', true);
        resetForm();
        refreshAll();
        return;
      }
      setMessage('Project updated.');
    } else {
      S.add(result.value);
      setMessage('Project saved.');
    }
    resetForm();
    refreshAll();
  });

  $('cancel-btn').addEventListener('click', function () {
    resetForm();
    setMessage('Edit cancelled.');
  });

  $('description').addEventListener('input', function () {
    $('char-count').textContent = String(this.value.length);
  });

  ['search', 'filter-status', 'filter-discipline'].forEach(function (id) {
    $(id).addEventListener('input', renderListing);
  });

  $('reset-btn').addEventListener('click', function () {
    $('search').value = '';
    $('filter-status').value = '';
    $('filter-discipline').value = '';
    renderListing();
  });

  $('listing').addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-action]');
    if (!btn) return;
    var id = btn.getAttribute('data-id');

    if (btn.getAttribute('data-action') === 'edit') {
      var rec = S.getById(id);
      if (rec) fillForm(rec);
    } else if (btn.getAttribute('data-action') === 'delete') {
      if (window.confirm('Delete this project record?')) {
        S.remove(id);
        if ($('project-id').value === id) resetForm();
        setMessage('Project deleted.');
        refreshAll();
      }
    }
  });

  refreshAll();
})();
