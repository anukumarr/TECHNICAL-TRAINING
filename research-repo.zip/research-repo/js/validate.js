/* validate.js - input validation for project records.
   Works in the browser (window.RepoValidate) and in Node (module.exports). */
(function (root) {
  'use strict';

  var STATUSES = ['Planned', 'Ongoing', 'Completed'];
  var MAX_SIZE_MB = 1000000;

  function clean(value) {
    return String(value == null ? '' : value).trim().replace(/\s+/g, ' ');
  }

  // "a, b ,, c" -> ["a","b","c"] (no blanks, no duplicates, case-insensitive)
  function parseKeywords(text) {
    var seen = {};
    var out = [];
    clean(text).split(',').forEach(function (k) {
      var word = clean(k);
      var key = word.toLowerCase();
      if (word && !seen[key]) {
        seen[key] = true;
        out.push(word);
      }
    });
    return out;
  }

  function isRealDate(text) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
    var p = text.split('-').map(Number);
    var d = new Date(p[0], p[1] - 1, p[2]);
    return d.getFullYear() === p[0] && d.getMonth() === p[1] - 1 && d.getDate() === p[2];
  }

  /* data     : raw form values
     existing : array of records already stored
     editId   : id of the record being edited (ignored in duplicate check)
     returns  : { valid, errors:{field:msg}, value:{cleaned record fields} } */
  function validateProject(data, existing, editId) {
    var errors = {};
    var v = {
      title: clean(data.title),
      researcher: clean(data.researcher),
      discipline: clean(data.discipline),
      status: clean(data.status),
      startDate: clean(data.startDate),
      size: clean(data.size),
      keywords: parseKeywords(data.keywords),
      description: clean(data.description)
    };

    if (!v.title) errors.title = 'Title is required.';
    else if (v.title.length < 3) errors.title = 'Title needs at least 3 characters.';
    else if (v.title.length > 80) errors.title = 'Title is too long (max 80).';
    else {
      var dup = (existing || []).some(function (r) {
        return r.id !== editId && r.title.toLowerCase() === v.title.toLowerCase();
      });
      if (dup) errors.title = 'A project with this title already exists.';
    }

    if (!v.researcher) errors.researcher = 'Researcher name is required.';
    else if (!/^[A-Za-z][A-Za-z .'\-]{1,49}$/.test(v.researcher))
      errors.researcher = 'Use letters, spaces, dots or hyphens only.';

    if (!v.discipline) errors.discipline = 'Select a discipline.';
    if (!v.status) errors.status = 'Select a status.';
    else if (STATUSES.indexOf(v.status) === -1) errors.status = 'Invalid status.';

    if (!v.startDate) errors.startDate = 'Start date is required.';
    else if (!isRealDate(v.startDate)) errors.startDate = 'Enter a valid date.';

    if (v.size === '') errors.size = 'Dataset size is required.';
    else if (isNaN(Number(v.size))) errors.size = 'Size must be a number.';
    else if (Number(v.size) < 0) errors.size = 'Size cannot be negative.';
    else if (Number(v.size) > MAX_SIZE_MB) errors.size = 'Size is unrealistically large.';
    else v.size = Number(v.size);

    if (v.keywords.length > 10) errors.keywords = 'Use at most 10 keywords.';
    if (v.description.length > 300) errors.description = 'Description is too long (max 300).';

    return { valid: Object.keys(errors).length === 0, errors: errors, value: v };
  }

  var api = {
    STATUSES: STATUSES,
    clean: clean,
    parseKeywords: parseKeywords,
    isRealDate: isRealDate,
    validateProject: validateProject
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.RepoValidate = api;
})(typeof window !== 'undefined' ? window : this);
